import SwiftUI

struct AuthView: View {
    @StateObject var viewModel = AuthViewModel()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                NavigationLink(destination: LoginView(viewModel: viewModel)) {
                    Text("Войти")
                        .foregroundColor(.white)
                        .frame(width: 280, height: 44)
                        .background(Color.blue)
                        .cornerRadius(8)
                }
                
                NavigationLink(destination: RegisterView(viewModel: viewModel)) {
                    Text("Регистрация")
                        .foregroundColor(.white)
                        .frame(width: 280, height: 44)
                        .background(Color.green)
                        .cornerRadius(8)
                }
            }
            .navigationBarTitle("Авторизация/Регистрация", displayMode: .inline)
        }
    }
}

struct AuthView_Previews: PreviewProvider {
    static var previews: some View {
        AuthView()
    }
}
