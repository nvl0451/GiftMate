//
//  Kurs3App.swift
//  Kurs3
//
//  Created by Никита Куприн on 18.03.2024.
//

import SwiftUI

@main
struct Kurs3App: App {
    @State private var isUserAuthenticated = UserDefaults.standard.string(forKey: "userToken") != nil
    
    var body: some Scene {
            WindowGroup {
                if isUserAuthenticated {
                    ContentView()
                } else {
                    AuthView()
                }
            }
        }
}
