import SwiftUI

struct ProfilePage: View {
    @State private var name: String = ""
    @State private var birthDate = Date()
    @State private var interests: String = ""
    @State private var profileImage: UIImage? = nil
    @State private var isImagePickerDisplay = false

    var body: some View {
        VStack {
            Image(uiImage: profileImage ?? UIImage(systemName: "person.crop.circle")!)
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .clipShape(Circle())
                .padding()
                .onTapGesture {
                    self.isImagePickerDisplay = true
                }
            
            TextField("Имя", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            DatePicker("Дата рождения", selection: $birthDate, displayedComponents: .date)
                .padding()
            
            TextField("Интересы", text: $interests)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Spacer()
        }
        .sheet(isPresented: $isImagePickerDisplay) {
            ImagePickerView(selectedImage: self.$profileImage, sourceType: .photoLibrary)
        }
    }
}
