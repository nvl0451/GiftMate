//
//  ContentView.swift
//  Kurs3
//
//  Created by Никита Куприн on 18.03.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomePage()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Главная")
                }

            SearchPage()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Друзья")
                }

            FavoritesPage()
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text("Избранное")
                }

            ProfilePage()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Профиль")
                }
        }
    }
}

struct HomePage: View {
    var body: some View {
        // Ваш код для главной страницы
        Text("Главная страница")
    }
}

struct SearchPage: View {
    var body: some View {
        // Ваш код для страницы поиска
        Text("Страница друзей")
    }
}

struct FavoritesPage: View {
    var body: some View {
        // Ваш код для страницы избранных
        Text("Страница избранных")
    }
}

#Preview {
    ContentView()
}
